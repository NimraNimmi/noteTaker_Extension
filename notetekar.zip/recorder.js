// recorder.js (runs inside offscreen.html, as ES module)
// Captures the tab's audio stream and records it to a downloadable webm file.

import { saveMeeting } from "./db.js";

let mediaRecorder = null;
let recordedChunks = [];
let audioContext = null;
let micStream = null;
let mixedStream = null;
let liveTranscriptText = "";

window.addEventListener("live-transcript-final", (e) => {
  liveTranscriptText += e.detail.text + " ";
});


chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg.type === "OFFSCREEN_START") {
    try {
      await startCapture(msg.streamId);
      return Promise.resolve({ ok: true });
    } catch (err) {
      console.error(err);
      return Promise.resolve({
        ok: false,
        error: err.message
      });
    }
  }

  if (msg.type === "OFFSCREEN_STOP") {
    stopCapture();
  }
});

async function startCapture(streamId) {
  try {
    // Capture the tab's audio (what's playing in the meeting - other participants)
    const tabStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId
        }
      },
      video: false
    });

    // Capture your microphone too (so your own voice is included)
    // Enable noise suppression / echo cancellation / auto gain to reduce noise.
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
    } catch (e) {
      console.warn("Mic access denied or unavailable, continuing with tab audio only.", e);
    }

    // Mix tab audio + mic audio into one stream using Web Audio API
    audioContext = new AudioContext();
    const destination = audioContext.createMediaStreamDestination();

    const tabSource = audioContext.createMediaStreamSource(tabStream);
    tabSource.connect(destination);
    // Also connect tab audio to speakers so you can still hear the meeting
    tabSource.connect(audioContext.destination);

    if (micStream) {
      const micSource = audioContext.createMediaStreamSource(micStream);

      // High-pass filter: cuts low-frequency rumble/hum (fans, AC, mic handling noise)
      const highPass = audioContext.createBiquadFilter();
      highPass.type = "highpass";
      highPass.frequency.value = 100; // remove rumble below ~100Hz

      // Compressor: evens out volume, reduces background noise prominence
      const compressor = audioContext.createDynamicsCompressor();
      compressor.threshold.value = -50;
      compressor.knee.value = 30;
      compressor.ratio.value = 12;
      compressor.attack.value = 0.003;
      compressor.release.value = 0.25;

      micSource.connect(highPass);
      highPass.connect(compressor);
      compressor.connect(destination);
    }

    mixedStream = destination.stream;

    // Start MediaRecorder for saving the file
    recordedChunks = [];
    liveTranscriptText = "";
    mediaRecorder = new MediaRecorder(mixedStream, { mimeType: "audio/webm" });
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) recordedChunks.push(e.data);
    };
    mediaRecorder.onstop = saveRecording;
    mediaRecorder.start();

    chrome.runtime.sendMessage({
      type: "RECORDING_STARTED"
    });

    // Notify transcription module to start using the SAME mixed stream
// Live transcription disabled.
// Full transcript will be generated
// automatically after recording ends.

    console.log("Recording started");
  } catch (err) {
    console.error("Capture error:", err);
    throw err;
  }
}

function stopCapture() {
  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  }

  if (micStream) micStream.getTracks().forEach((t) => t.stop());
  if (mixedStream) mixedStream.getTracks().forEach((t) => t.stop());
  if (audioContext) audioContext.close();
}

function saveRecording() {
  const blob = new Blob(recordedChunks, { type: "audio/webm" });

  const meeting = {
    id: crypto.randomUUID(),
    title: "Meeting recorded " + new Date().toLocaleString(),
    date: Date.now(),
    audioBlob: blob,
    transcript: null,
    keyPoints: null,
    liveTranscript: liveTranscriptText.trim()
  };

  saveMeeting(meeting).then(() => {
    chrome.runtime.sendMessage({
      type: "RECORDING_SAVED",
      meetingId: meeting.id,
      title: meeting.title,
      autoTranscribe: true
    });
  }).catch((err) => {
    console.error("Failed to save meeting to DB:", err);
    chrome.runtime.sendMessage({
      type: "RECORDING_SAVED",
      meetingId: meeting.id,
      title: meeting.title,
      autoTranscribe: true
    });
  });

  // Also save a .webm copy to Downloads as a backup
  const reader = new FileReader();
  reader.onload = () => {
    const filename = `meeting-recording-${Date.now()}.webm`;
    chrome.downloads.download({
      url: reader.result,
      filename: `MeetNotes/${filename}`,
      saveAs: false
    });
  };
  reader.readAsDataURL(blob);
}
