# Meet Notetaker (No-Bot) — Free, Local, No API Keys

Records and transcribes Google Meet calls from YOUR OWN browser tab —
no separate bot account, no "join meeting / admit" needed. 100% free.

## Folder structure

```
meet-notetaker-extension/
├── manifest.json        # Extension config, permissions, CSP
├── background.js        # Service worker: manages start/stop, offscreen doc
├── offscreen.html        # Hidden page where actual capture/recording happens (MV3 requirement)
├── recorder.js          # Captures tab audio + your mic, mixes them, saves .webm
├── transcription.js     # Live captions of YOUR voice (Web Speech API)
├── content.js           # Runs on meet.google.com, reads meeting title/URL
├── popup.html           # Extension popup UI
├── popup.js             # All UI logic: recording controls, Whisper transcription,
│                         #   summarization (key points), and Q&A chat
├── groq.js              # Optional free Groq API integration for smart summaries/chat
├── styles.css           # Popup styling
├── lib/                  # Local copy of transformers.js (download via setup.sh)
├── setup.sh              # One-time script to download transformers.js
└── icons/                # Extension icons
```

## How it works — step by step

### 1. Setup (one-time)

**Step A: Download the local AI library**
Chrome extensions cannot load scripts from a CDN (CSP restriction), so
`transformers.js` (used for Whisper transcription) must be downloaded once
into the `lib/` folder.

Open a terminal **inside the `meet-notetaker-extension` folder** and run:

```
bash setup.sh
```

On Windows without bash, just download this URL and save it as
`lib/transformers.min.js`:
https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.0.0/dist/transformers.min.js

**Step B: Load the extension**
- Go to `chrome://extensions`
- Enable "Developer mode" (top right)
- Click "Load unpacked" → select the `meet-notetaker-extension` folder

### 2. During the meeting
- Join your Google Meet normally (in your own browser, as yourself — already admitted)
- Click the extension icon → **Start Recording**
  - `background.js` creates a hidden "offscreen document"
  - `recorder.js` (inside it) uses `chrome.tabCapture` to grab the **audio of your Meet tab**
    (everyone's voices, since that's what plays through the tab)
  - It also grabs **your microphone** and mixes both into one audio stream
  - `MediaRecorder` saves this mixed stream to a `.webm` file in
    `Downloads/MeetNotes/`
  - `transcription.js` runs Chrome's built-in **Web Speech API** on your mic
    in parallel — shows **live captions of your own speech** in the popup
    (this part is instant/real-time, but mic-only — see limitation below)

### 3. After the meeting
- Click **Stop Recording** → the `.webm` file finishes saving to
  `Downloads/MeetNotes/meeting-recording-<timestamp>.webm`
- In the popup, under "Generate Notes / Summary":
  - Select that `.webm` file
  - Click **Transcribe Recording (Whisper)**
  - This loads **Whisper (tiny/base model)** via `transformers.js`
    (Hugging Face's free in-browser AI library — runs on YOUR computer,
    no API key, no cost, no data sent anywhere)
  - First run downloads the model (~150MB, cached after that)
  - Produces a **full, accurate transcript of EVERYONE** in the meeting

### 4. Key Points
- Automatically generated using a local TF-IDF extractive summarizer
  (pure JS, no AI model needed) — picks the most "information-dense"
  sentences as bullet points

### 5. Ask Questions
- Type a question in "Ask About This Meeting"
- Uses local keyword-overlap retrieval to find and show the most relevant
  transcript sentences as the answer

---

## IMPORTANT — Real-time transcription limitation (and the honest tradeoff)

Chrome's `SpeechRecognition` (Web Speech API) can **only** listen to a
**microphone**, not an arbitrary audio stream (like tab/system audio).
This is a hard browser restriction — no free workaround exists for true
live transcription of *everyone's* voices.

What you get instead:
- **Live**: captions of your own voice only (via your mic) — real-time
- **Post-meeting**: full transcript of everyone via Whisper, run locally
  after you stop recording — takes a few minutes depending on meeting length

This is the best possible **free, no-API-key** setup. If you ever want
true real-time transcription of all participants, the only way is a
paid streaming STT API (Deepgram, AssemblyAI, etc.) — explicitly avoided
here per your requirements.

---

## Optional free upgrade for better Q&A / summaries

If you want noticeably smarter summaries and chat answers (full sentences,
reasoning, not just extracted lines), you can optionally add **Groq's API**
(https://console.groq.com) — they offer a generous free tier (no credit
card) with very fast Llama 3 models. This is OPTIONAL — the extension works
fully without it. If you want this added, say so and I'll wire up
`chat.js`/`notes-generator.js` to call Groq with your free key, with a
toggle to disable it and fall back to the local-only mode above.

## Permissions explained
- `tabCapture` — capture audio from your Meet tab
- `offscreen` — required in MV3 to run MediaRecorder/AudioContext
- `downloads` — save the recording file
- `storage` — save transcripts/settings locally
- Host permissions for `cdn.jsdelivr.net` / `huggingface.co` — to load
  the free Whisper model files
