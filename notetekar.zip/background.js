// background.js
// Manages tab capture lifecycle and message routing between popup, content script, and offscreen document.
//
// Recording state is persisted in chrome.storage.session so it survives
// service-worker restarts (Chrome can kill the SW at any time). The
// offscreen document's existence is the ultimate source of truth for
// whether a recording is actually in progress.

const STATE_KEY = "recordingState";

async function getState() {
  const data = await chrome.storage.session.get([STATE_KEY]);
  return data[STATE_KEY] || { isRecording: false, tabId: null, startTime: null };
}

async function setState(state) {
  await chrome.storage.session.set({ [STATE_KEY]: state });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_STATE") {
    getState().then(async (state) => {
      if (state.isRecording) {
        const existing = await chrome.runtime.getContexts({
          contextTypes: ["OFFSCREEN_DOCUMENT"]
        });

        if (existing.length === 0) {
          state = {
            isRecording: false,
            tabId: null,
            startTime: null,
            isStopping: false
          };
          await setState(state);
        }
      }

      sendResponse(state);
    });

    return true;
  }

  if (msg.type === "START_RECORDING") {
    startRecording(msg.tabId).then(sendResponse);
    return true;
  }

  if (msg.type === "STOP_RECORDING") {
    stopRecording().then(sendResponse);
    return true;
  }

  if (msg.type === "TRANSCRIPT_UPDATE") {
    chrome.runtime.sendMessage({
      type: "TRANSCRIPT_CHUNK",
      text: msg.text,
      final: msg.final
    }).catch(() => {});
    return;
  }

  if (msg.type === "RECORDING_SAVED") {
    setState({
      isRecording: false,
      tabId: null,
      startTime: null,
      isStopping: false
    }).then(() => {
      chrome.runtime.sendMessage({
        type: "RECORDING_DONE",
        meetingId: msg.meetingId,
        title: msg.title,
        autoTranscribe: true
      }).catch(() => {});
    });

    return;
  }

  if (msg.type === "RECORDING_SAVE_FAILED") {
    setState({
      isRecording: false,
      tabId: null,
      startTime: null,
      isStopping: false
    }).then(() => {
      chrome.runtime.sendMessage({
        type: "RECORDING_DONE_ERROR",
        error: msg.error
      }).catch(() => {});
    });

    return;
  }
});


async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length > 0) return;

  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA"],
    justification: "Recording and transcribing tab audio for meeting notes"
  });
}

async function startRecording(tabId) {
  try {
    const state = await getState();
    const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });

    // If a recording is already in progress, do NOT tear it down (that loses
    // the in-memory audio data). Just report success without restarting.
    if (state.isRecording && existing.length > 0) {
      return { ok: true, alreadyRecording: true };
    }

    // If state says recording but offscreen doc is gone, state is stale - clear it.
    if (existing.length > 0 && !state.isRecording) {
      await chrome.offscreen.closeDocument();
      await new Promise((r) => setTimeout(r, 300));
    }

    // getMediaStreamId requires the target tab to be the active/focused tab
    // in its window at the time of the call. Bring it to the front.
    try {
      const targetTab = await chrome.tabs.get(tabId);

      await chrome.tabs.update(tabId, { active: true });
      await chrome.windows.update(targetTab.windowId, { focused: true });

      // Chrome ko proper focus lene do
      await new Promise((r) => setTimeout(r, 1000));

      // await chrome.tabs.update(tabId, { active: true });
      // await chrome.windows.update(targetTab.windowId, { focused: true });
      // await new Promise((r) => setTimeout(r, 100));
    } catch (focusErr) {
      console.warn("Could not focus target tab:", focusErr);
    }

    await ensureOffscreenDocument();
    await new Promise((r) => setTimeout(r, 150));

    let streamId;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
    } catch (capErr) {
      throw new Error("tabCapture.getMediaStreamId failed: " + (capErr?.message || String(capErr) || "no message — make sure the Meet tab is the active/focused tab, and only one capture is active at a time"));
    }

    await setState({ isRecording: true, tabId, startTime: Date.now() });

    await chrome.runtime.sendMessage({
      type: "OFFSCREEN_START",
      streamId
    });

    return { ok: true };
  } catch (err) {
    console.error("startRecording error:", err);
    await setState({ isRecording: false, tabId: null, startTime: null });
    return { ok: false, error: err?.message || String(err) || "Unknown error" };
  }
}

async function stopRecording() {
  chrome.runtime.sendMessage({ type: "OFFSCREEN_STOP" });
  // Don't clear isRecording yet - wait for RECORDING_SAVED to confirm the
  // audio was actually persisted. But mark as "stopping" so UI can react.
  const state = await getState();
  await setState({ ...state, isStopping: true });
  return { ok: true };
}
