// popup.js
// Minimal popup: start/stop recording controls and a link to the full dashboard.

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");
const openDashboardBtn = document.getElementById("openDashboardBtn");

async function refreshState() {
  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  if (state && state.isRecording) {
    const stopping = !!state.isStopping;
    statusEl.textContent = stopping ? "Stopping..." : "Recording...";
    statusEl.classList.add("recording");
    startBtn.textContent = stopping ? "Stopping..." : "Recording...";
    startBtn.disabled = true;
    stopBtn.textContent = stopping ? "Stopping..." : "Stop Recording";
    stopBtn.disabled = stopping;
  } else {
    statusEl.textContent = "Not recording";
    statusEl.classList.remove("recording");
    startBtn.textContent = "Start Recording";
    startBtn.disabled = false;
    stopBtn.textContent = "Stop Recording";
    stopBtn.disabled = true;
  }
}

startBtn.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const supported =
    tab.url.includes("meet.google.com") ||
    tab.url.includes("zoom.us");

  if (!supported) {
    alert("Switch to your Google Meet or Zoom tab first, then click Start. (Recording will continue in the background after that — you can switch tabs freely.)");
    return;
  }

  startBtn.disabled = true;
  startBtn.textContent = "Starting...";

  const res = await chrome.runtime.sendMessage({ type: "START_RECORDING", tabId: tab.id });
  if (!res || !res.ok) {
    startBtn.disabled = false;
    startBtn.textContent = "Start Recording";

    alert(
      "Failed to start: " +
      (res?.error || "Unknown error")
    );
  }

  await refreshState();
});

stopBtn.addEventListener("click", async () => {
  stopBtn.disabled = true;
  stopBtn.textContent = "Stopping...";
  await chrome.runtime.sendMessage({ type: "STOP_RECORDING" });
  await refreshState();
});

openDashboardBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});

chrome.runtime.onMessage.addListener((msg) => {

  if (msg.type === "RECORDING_STARTED") {

    statusEl.textContent = "Recording...";
    statusEl.classList.add("recording");

    startBtn.disabled = true;
    startBtn.textContent = "Recording...";

    stopBtn.disabled = false;
    stopBtn.textContent = "Stop Recording";
  }

  if (
      msg.type === "RECORDING_DONE" ||
      msg.type === "RECORDING_DONE_ERROR"
  ) {
      refreshState();
  }
});

refreshState();
