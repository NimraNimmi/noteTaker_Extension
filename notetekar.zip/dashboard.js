// dashboard.js
// Full meeting management dashboard: list recordings, transcribe, summarize, chat.

import { pipeline, env } from "./lib/transformers.min.js";
import { getGroqKey, setGroqKey, groqSummarize, groqAnswer } from "./groq.js";
import { getAllMeetings, getMeeting, updateMeeting, deleteMeeting } from "./db.js";

env.allowLocalModels = false;
env.useBrowserCache = true;

const startBtn = document.getElementById("startBtn");
const stopBtn = document.getElementById("stopBtn");
const statusEl = document.getElementById("status");
const meetingsListEl = document.getElementById("meetingsList");
const groqKeyInput = document.getElementById("groqKeyInput");
const saveKeyBtn = document.getElementById("saveKeyBtn");
const keyStatusEl = document.getElementById("keyStatus");

const noSelectionEl = document.getElementById("noSelection");
const meetingViewEl = document.getElementById("meetingView");
const meetingTitleEl = document.getElementById("meetingTitle");
const audioPlayerEl = document.getElementById("audioPlayer");
const transcribeBtn = document.getElementById("transcribeBtn");
const deleteBtn = document.getElementById("deleteBtn");
const transcribeStatusEl = document.getElementById("transcribeStatus");
const liveTranscriptEl = document.getElementById("liveTranscript");
const fullTranscriptEl = document.getElementById("fullTranscript");
const keyPointsEl = document.getElementById("keyPoints");
const chatInputEl = document.getElementById("chatInput");
const chatBtn = document.getElementById("chatBtn");
const chatAnswerEl = document.getElementById("chatAnswer");

let currentMeetingId = null;
let transcriptSentences = [];
let fullMeetingTranscript = "";
let whisperPipeline = null;

// ---------- Recording state (mirrors popup behavior) ----------

async function refreshState() {
  const state = await chrome.runtime.sendMessage({ type: "GET_STATE" });
  if (state && state.isRecording) {
    statusEl.textContent = state.isStopping ? "Stopping..." : "Recording...";
    statusEl.classList.add("recording");
    startBtn.textContent = state.isStopping ? "Stopping..." : "Recording...";
    startBtn.disabled = true;
    stopBtn.disabled = !!state.isStopping;
    stopBtn.textContent = state.isStopping ? "Stopping..." : "Stop Recording";
  } else {
    statusEl.textContent = "Not recording";
    statusEl.classList.remove("recording");
    startBtn.textContent = "Start Recording";
    startBtn.disabled = false;
    stopBtn.disabled = true;
    stopBtn.textContent = "Stop Recording";
  }
}

startBtn.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const meetTabs = await chrome.tabs.query({
    url: "https://meet.google.com/*"
  });

  const zoomTabs = await chrome.tabs.query({
    url: "https://*.zoom.us/*"
  });

  const tabs = [...meetTabs, ...zoomTabs];
  let targetTab = null;
  if (tab && tab.url &&
    tab.url.includes("meet.google.com") ||
    tab.url.includes("zoom.us")
  ) {
    targetTab = tab;
  } else if (tabs.length > 0) {
    targetTab = tabs[0];
  }

  if (!targetTab) {
    alert("Open a Google Meet tab first, then click Start Recording.");
    return;
  }

  startBtn.disabled = true;
  startBtn.textContent = "Starting...";

  const res = await chrome.runtime.sendMessage({ type: "START_RECORDING", tabId: targetTab.id });
  if (!res || !res.ok) {
    startBtn.disabled = false;
    startBtn.textContent = "Start Recording";

    alert(
      "Failed to start: " +
      (res?.error || "Unknown error")
    );
  }

  await refreshState();
});

stopBtn.addEventListener("click", async () => {
  stopBtn.disabled = true;
  stopBtn.textContent = "Stopping...";
  await chrome.runtime.sendMessage({ type: "STOP_RECORDING" });
  await refreshState();
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "RECORDING_STARTED") {

    statusEl.textContent = "Recording...";
    statusEl.classList.add("recording");

    startBtn.disabled = true;
    startBtn.textContent = "Recording...";

    stopBtn.disabled = false;
  }

  if (msg.type === "TRANSCRIPT_CHUNK" && msg.final) {
    liveTranscriptEl.textContent += msg.text + " ";
    liveTranscriptEl.scrollTop = liveTranscriptEl.scrollHeight;
  }
  if (msg.type === "RECORDING_DONE") {
    refreshState();

    loadMeetingsList().then(async () => {
      if (msg.meetingId) {
        await selectMeeting(msg.meetingId);

        if (msg.autoTranscribe !== false) {
          await transcribeMeeting(msg.meetingId, false);
        }
      }
    });

  }
  if (msg.type === "RECORDING_DONE_ERROR") {
    refreshState();
    alert("Recording failed to save: " + msg.error);
  }
});

// ---------- Groq key ----------

saveKeyBtn.addEventListener("click", async () => {
  const key = groqKeyInput.value.trim();
  await setGroqKey(key);
  keyStatusEl.textContent = key ? "Groq key saved. Smart summaries/chat enabled." : "Key cleared. Using local-only mode.";
});

// ---------- Meetings list ----------

async function loadMeetingsList() {
  const meetings = await getAllMeetings();
  if (!meetings.length) {
    meetingsListEl.innerHTML = '<div class="muted">No recordings yet.</div>';
    return;
  }

  meetingsListEl.innerHTML = meetings.map(m => `
    <div class="meeting-item ${m.id === currentMeetingId ? "active" : ""}" data-id="${m.id}">
      <div class="meeting-item-title">${escapeHtml(m.title)}</div>
      <div class="meeting-item-date">${new Date(m.date).toLocaleString()}</div>
      <div class="meeting-item-status">${m.transcript ? "Transcribed" : "Not transcribed"}</div>
    </div>
  `).join("");

  meetingsListEl.querySelectorAll(".meeting-item").forEach(el => {
    el.addEventListener("click", () => selectMeeting(el.dataset.id));
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------- Select / view a meeting ----------

async function selectMeeting(id) {
  currentMeetingId = id;
  const meeting = await getMeeting(id);
  if (!meeting) return;

  noSelectionEl.classList.add("hidden");
  meetingViewEl.classList.remove("hidden");
  meetingTitleEl.textContent = meeting.title;

  const audioUrl = URL.createObjectURL(meeting.audioBlob);
  audioPlayerEl.src = audioUrl;

  liveTranscriptEl.textContent = meeting.liveTranscript || "(no live captions captured)";

  if (meeting.transcript) {
    fullMeetingTranscript = meeting.transcript;
    transcriptSentences = splitIntoSentences(fullMeetingTranscript);
    fullTranscriptEl.textContent = fullMeetingTranscript;
    transcribeStatusEl.textContent = "Transcribed.";
    transcribeBtn.textContent = "Re-transcribe";
  } else {
    fullMeetingTranscript = "";
    transcriptSentences = [];
    fullTranscriptEl.textContent = "(not transcribed yet — starting automatically...)";
    transcribeStatusEl.textContent = "";
    transcribeBtn.textContent = "Transcribe (Whisper)";
  }

  if (meeting.keyPoints) {
    keyPointsEl.innerHTML = meeting.keyPoints.replace(/\n/g, "<br>");
  } else {
    keyPointsEl.textContent = "(none yet — transcribe first)";
  }

  chatAnswerEl.textContent = "";
  chatInputEl.value = "";

  await loadMeetingsList();

  if (!meeting.transcript) {
    await transcribeMeeting(id, true);
  }
}

// ---------- Delete ----------

deleteBtn.addEventListener("click", async () => {
  if (!currentMeetingId) return;
  if (!confirm("Delete this recording and its transcript? This cannot be undone.")) return;
  await deleteMeeting(currentMeetingId);
  currentMeetingId = null;
  meetingViewEl.classList.add("hidden");
  noSelectionEl.classList.remove("hidden");
  await loadMeetingsList();
});

// ---------- Whisper transcription ----------

transcribeBtn.addEventListener("click", async () => {
  if (!currentMeetingId) return;
  await transcribeMeeting(currentMeetingId, true);
});

// transcribeMeeting: transcribes the given meeting's audio with Whisper.
// If isManual is false (auto-transcribe), only runs if not already transcribed.
async function transcribeMeeting(meetingId, isManual) {
  const meeting = await getMeeting(meetingId);
  if (!meeting) return;

  if (!isManual && meeting.transcript) {
    return;
  }

  if (isManual) {
    await updateMeeting(meetingId, {
      transcript: null,
      keyPoints: null
    });
  }

  const isCurrent = meetingId === currentMeetingId;
  if (isCurrent) {
    transcribeBtn.disabled = true;
    transcribeStatusEl.textContent = "Loading Whisper model (first time may take a minute)...";
  }

  try {
    if (!whisperPipeline) {
      whisperPipeline = await pipeline("automatic-speech-recognition", "Xenova/whisper-small");
    }

    if (isCurrent) {
      transcribeStatusEl.textContent = "Transcribing... this may take a few minutes for long meetings.";
    }

    const audioUrl = URL.createObjectURL(meeting.audioBlob);
    const result = await whisperPipeline(audioUrl, {
      chunk_length_s: 30,
      stride_length_s: 5,
      return_timestamps: true
    });

    const transcript = result.text;
    await updateMeeting(meetingId, { transcript });

    if (isCurrent) {
      fullMeetingTranscript = transcript;
      transcriptSentences = splitIntoSentences(fullMeetingTranscript);
      fullTranscriptEl.textContent = fullMeetingTranscript;
      transcribeStatusEl.textContent = "Transcription complete (" + transcriptSentences.length + " sentences).";
      transcribeBtn.textContent = "Re-transcribe";
      await generateKeyPoints();
    } else {
      // generate key points for the non-active meeting too, using local summary
      const sentences = splitIntoSentences(transcript);
      const groqKey = await getGroqKey();
      let summary = null;
      if (groqKey) summary = await groqSummarize(transcript);
      if (!summary) {
        const scored = scoreSentencesByTfIdf(sentences);
        const topN = Math.max(3, Math.min(8, Math.ceil(sentences.length * 0.15)));
        const top = scored.sort((a, b) => b.score - a.score).slice(0, topN).sort((a, b) => a.index - b.index);
        summary = top.map(s => "• " + s.text.trim()).join("\n");
      }
      await updateMeeting(meetingId, { keyPoints: summary });
    }

    await loadMeetingsList();
  } catch (err) {
    console.error("Auto-transcribe error:", err);
    if (isCurrent) transcribeStatusEl.textContent = "Error: " + err.message;
  } finally {
    if (isCurrent) transcribeBtn.disabled = false;
  }
}

// ---------- Summarization ----------

function splitIntoSentences(text) {
  return text.replace(/\s+/g, " ").match(/[^.!?]+[.!?]+/g) || [text];
}

async function generateKeyPoints() {
  if (!transcriptSentences.length) {
    keyPointsEl.textContent = "Transcribe a recording first.";
    return;
  }

  const groqKey = await getGroqKey();
  let summary = null;

  if (groqKey) {
    keyPointsEl.textContent = "Generating smart summary via Groq...";
    summary = await groqSummarize(fullMeetingTranscript);
  }

  if (!summary) {
    const scored = scoreSentencesByTfIdf(transcriptSentences);
    const topN = Math.max(3, Math.min(8, Math.ceil(transcriptSentences.length * 0.15)));
    const top = scored.sort((a, b) => b.score - a.score).slice(0, topN).sort((a, b) => a.index - b.index);
    summary = top.map(s => "• " + s.text.trim()).join("\n");
  }

  keyPointsEl.innerHTML = summary.replace(/\n/g, "<br>");
  if (currentMeetingId) await updateMeeting(currentMeetingId, { keyPoints: summary });
}

function scoreSentencesByTfIdf(sentences) {
  const stopwords = new Set(["the", "a", "an", "and", "or", "but", "is", "are", "was", "were",
    "to", "of", "in", "on", "for", "with", "this", "that", "it", "we", "you", "i", "they",
    "he", "she", "be", "as", "at", "by", "so", "if", "then", "than", "there", "what",
    "which", "who", "whom", "these", "those", "am", "do", "does", "did", "have", "has",
    "had", "not", "just", "like", "um", "uh", "okay", "ok", "yeah", "right"]);

  const docFreq = {};
  const sentenceWords = sentences.map(s =>
    s.toLowerCase().match(/[a-z']+/g)?.filter(w => !stopwords.has(w) && w.length > 2) || []
  );

  sentenceWords.forEach(words => {
    const unique = new Set(words);
    unique.forEach(w => docFreq[w] = (docFreq[w] || 0) + 1);
  });

  const N = sentences.length;
  return sentences.map((text, index) => {
    const words = sentenceWords[index];
    if (!words.length) return { text, index, score: 0 };
    const tfidfSum = words.reduce((sum, w) => {
      const tf = 1 / words.length;
      const idf = Math.log(N / (docFreq[w] || 1) + 1);
      return sum + tf * idf;
    }, 0);
    return { text, index, score: tfidfSum / Math.sqrt(words.length) };
  });
}

// ---------- Chat / Q&A ----------

chatBtn.addEventListener("click", async () => {
  const question = chatInputEl.value.trim();
  if (!question) return;
  if (!transcriptSentences.length) {
    chatAnswerEl.textContent = "Transcribe this meeting first.";
    return;
  }

  chatBtn.disabled = true;
  const groqKey = await getGroqKey();
  if (groqKey) {
    chatAnswerEl.textContent = "Thinking...";
    const result = await groqAnswer(question, fullMeetingTranscript);
    if (result) {
      chatAnswerEl.textContent = result;
      chatBtn.disabled = false;
      return;
    }
    chatAnswerEl.textContent = "Groq failed, using local search...";
  }

  const answer = retrieveAnswer(question, transcriptSentences);
  chatAnswerEl.textContent = answer;
  chatBtn.disabled = false;
});

function retrieveAnswer(question, sentences) {
  const qWords = question.toLowerCase().match(/[a-z']+/g) || [];
  const scored = sentences.map((s, i) => {
    const sWords = s.toLowerCase().match(/[a-z']+/g) || [];
    const overlap = qWords.filter(w => sWords.includes(w)).length;
    return { text: s, index: i, score: overlap };
  });

  const top = scored.filter(s => s.score > 0).sort((a, b) => b.score - a.score).slice(0, 3);
  if (!top.length) return "I couldn't find anything in the transcript matching that question.";

  top.sort((a, b) => a.index - b.index);
  return top.map(s => s.text.trim()).join("\n\n");
}

// ---------- Init ----------

document.addEventListener("DOMContentLoaded", async () => {
  await refreshState();
  await loadMeetingsList();

  const savedKey = await getGroqKey();
  if (savedKey) {
    groqKeyInput.value = savedKey;
    keyStatusEl.textContent = "Groq key loaded. Smart mode enabled.";
  }

  const meetings = await getAllMeetings();
  const pending = meetings.find(m => m.audioBlob && !m.transcript);

  if (pending) {
    await selectMeeting(pending.id);
    await transcribeMeeting(pending.id, false);
  }
});
