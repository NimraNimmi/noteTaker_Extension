// groq.js
// Optional integration with Groq's free API (https://console.groq.com).
// Provides much better summaries and Q&A than the local fallback methods.
// If no API key is saved, callers should fall back to local logic.

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "llama-3.3-70b-versatile"; // free tier model on Groq

export async function getGroqKey() {
  const data = await chrome.storage.local.get(["groqApiKey"]);
  return data.groqApiKey || null;
}

export async function setGroqKey(key) {
  await chrome.storage.local.set({ groqApiKey: key });
}

async function callGroq(messages, maxTokens = 1024) {
  const apiKey = await getGroqKey();
  if (!apiKey) return null;

  try {
    const res = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages,
        max_tokens: maxTokens,
        temperature: 0.3
      })
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("Groq API error:", res.status, errText);
      return null;
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content || null;
  } catch (err) {
    console.error("Groq request failed:", err);
    return null;
  }
}

// Generates a clean meeting summary + bullet key points from a transcript.
// Returns null on failure (caller should fall back to local TF-IDF summary).
export async function groqSummarize(transcript) {
  // Truncate very long transcripts to stay within free-tier token limits
  const truncated = transcript.length > 24000 ? transcript.slice(0, 24000) + "..." : transcript;

  const messages = [
    {
      role: "system",
      content: "You are a meeting notes assistant. Given a raw meeting transcript, produce: " +
               "1) A 2-3 sentence overview, 2) Key discussion points as bullet points, " +
               "3) Action items / decisions (if any) as bullet points. Be concise and factual. " +
               "Use Markdown formatting."
    },
    { role: "user", content: `Transcript:\n\n${truncated}` }
  ];

  return await callGroq(messages, 1024);
}

// Answers a question about the meeting using the transcript as context.
// Returns null on failure (caller should fall back to local keyword retrieval).
export async function groqAnswer(question, transcript) {
  const truncated = transcript.length > 24000 ? transcript.slice(0, 24000) + "..." : transcript;

  const messages = [
    {
      role: "system",
      content: "You answer questions about a meeting using only the provided transcript. " +
               "If the answer isn't in the transcript, say so clearly. Be concise."
    },
    {
      role: "user",
      content: `Transcript:\n\n${truncated}\n\nQuestion: ${question}`
    }
  ];

  return await callGroq(messages, 512);
}
